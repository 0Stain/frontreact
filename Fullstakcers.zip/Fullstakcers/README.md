# MERN_A_to_Z

### To Run the app (server)

##### Make sure you are in - MERN_A_to_Z/ directory & type the following command

```sh
$ npm install
$ npm run app
```

[Read My Article on LogRocket Blog about this repository](https://blog.logrocket.com/mern-stack-a-to-z-part-1/)

### You will find the front end part (MERN stack A to Z - Part-2) here.

[FrontEnd - (Client)](https://github.com/nurislam03/MERN_A_to_Z_Client)
