# MERN_A_to_Z_Client

### To Run the app (Client - React)

##### Make sure you are in - MERN_A_to_Z_Client/mern_a_to_z_client/  directory & type the following command

```sh
$ npm install
$ npm start
```

### To Explore all features in this project you need to connect the server first. Here you will find the necessary files (backend/server).

##### GitHub Repo - Backend/Server
[https://github.com/nurislam03/MERN_A_to_Z](https://github.com/nurislam03/MERN_A_to_Z)

#### Read My Article about this server side coding
[LogRocket Article Link](https://blog.logrocket.com/mern-stack-a-to-z-part-1/)